# Dataset

Place the actual agricultural CSV/Excel dataset used for the project in this folder.

The project brief describes data covering agricultural activities, seasons, geographical areas, farming conditions, environmental conditions, crop production, resource usage, and economic performance.

No actual dataset was included in the supplied project PDF, so no fabricated dataset has been added.
